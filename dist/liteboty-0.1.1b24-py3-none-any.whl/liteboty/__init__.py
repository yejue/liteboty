"""
LiteBoty - A lightweight robot development framework
"""

__version__ = "0.1.0"
