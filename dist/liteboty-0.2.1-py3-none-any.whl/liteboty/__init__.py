"""
LiteBoty - A lightweight robot development framework
"""

__version__ = "0.2.0"
